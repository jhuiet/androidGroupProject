package kidwella2.nku.edu.testgraph;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class RepGraph extends AppCompatActivity implements View.OnClickListener {
    private Button repsBtn;
    private Button setsBtn;
    private Button weightBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repsBtn = (Button) findViewById(R.id.reps);
        setsBtn = (Button) findViewById(R.id.sets);
        weightBtn = (Button) findViewById(R.id.weight);

        repsBtn.setOnClickListener(this);
        setsBtn.setOnClickListener(this);
        weightBtn.setOnClickListener(this);

        GraphView graph = (GraphView) findViewById(R.id.graph);
        LineGraphSeries<DataPoint> rep = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(1, 1),
                new DataPoint(2, 4),
                new DataPoint(3, 3),
                new DataPoint(4, 5),
                new DataPoint(5, 6),
                new DataPoint(6, 4),
                new DataPoint(7, 6),
                new DataPoint(8, 1),
                new DataPoint(9, 4),
                new DataPoint(10, 3),
                new DataPoint(11, 5),
                new DataPoint(12, 6),
                new DataPoint(13, 4),
                new DataPoint(14, 6),
                new DataPoint(15, 1),
                new DataPoint(16, 4),
                new DataPoint(17, 3),
                new DataPoint(18, 5),
                new DataPoint(19, 6),
                new DataPoint(20, 4)/*,
                new DataPoint(21, 6),
                new DataPoint(22, 1),
                new DataPoint(23, 4),
                new DataPoint(24, 3),
                new DataPoint(25, 5),
                new DataPoint(26, 6),
                new DataPoint(27, 4),
                new DataPoint(28, 6),
                new DataPoint(29, 1),
                new DataPoint(30, 4),
                new DataPoint(31, 3)*/
        });
        graph.addSeries(rep);
        rep.setColor(Color.GREEN);
        graph.setTitle("Reps");

        graph.getViewport().setMinX(1);
        graph.getViewport().setMaxX(20);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.reps:
                Intent resume = new Intent(RepGraph.this, Graph.class);
                startActivity(resume);
                break;
            case R.id.sets:
                Intent resumeSet = new Intent(RepGraph.this, SetGraph.class);
                startActivity(resumeSet);
                break;
            case R.id.weight:
                Intent resumeWeight = new Intent(RepGraph.this, WeightGraph.class);
                startActivity(resumeWeight);
                break;
        }
    }

}
