package kidwella2.nku.edu.testgraph;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class WeightGraph extends AppCompatActivity implements View.OnClickListener {
    private Button repsBtn;
    private Button setsBtn;
    private Button weightBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repsBtn = (Button) findViewById(R.id.reps);
        setsBtn = (Button) findViewById(R.id.sets);
        weightBtn = (Button) findViewById(R.id.weight);

        repsBtn.setOnClickListener(this);
        setsBtn.setOnClickListener(this);
        weightBtn.setOnClickListener(this);

        GraphView graph = (GraphView) findViewById(R.id.graph);
        LineGraphSeries<DataPoint> weight = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(1, 40),
                new DataPoint(2, 47),
                new DataPoint(3, 45),
                new DataPoint(4, 40),
                new DataPoint(5, 46),
                new DataPoint(6, 50),
                new DataPoint(7, 45),
                new DataPoint(8, 44),
                new DataPoint(9, 48),
                new DataPoint(10, 52),
                new DataPoint(11, 50),
                new DataPoint(12, 49),
                new DataPoint(13, 55),
                new DataPoint(14, 42),
                new DataPoint(15, 47),
                new DataPoint(16, 51),
                new DataPoint(17, 50),
                new DataPoint(18, 51),
                new DataPoint(19, 49),
                new DataPoint(20, 54)/*,
                new DataPoint(21, 5),
                new DataPoint(22, 1),
                new DataPoint(23, 4),
                new DataPoint(24, 3),
                new DataPoint(25, 5),
                new DataPoint(26, 6),
                new DataPoint(27, 4),
                new DataPoint(28, 6),
                new DataPoint(29, 1),
                new DataPoint(30, 4),
                new DataPoint(31, 3)*/
        });
        graph.addSeries(weight);
        weight.setColor(Color.RED);

        graph.getViewport().setMinX(1);
        graph.getViewport().setMaxX(20);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.reps:
                Intent resumeRep = new Intent(WeightGraph.this, RepGraph.class);
                startActivity(resumeRep);
                break;
            case R.id.sets:
                Intent resumeSet = new Intent(WeightGraph.this, SetGraph.class);
                startActivity(resumeSet);
                break;
            case R.id.weight:
                Intent resume = new Intent(WeightGraph.this, Graph.class);
                startActivity(resume);
                break;
        }
    }

}
