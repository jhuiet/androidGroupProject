package kidwella2.nku.edu.testgraph;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class SetGraph extends AppCompatActivity implements View.OnClickListener {
    private Button repsBtn;
    private Button setsBtn;
    private Button weightBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repsBtn = (Button) findViewById(R.id.reps);
        setsBtn = (Button) findViewById(R.id.sets);
        weightBtn = (Button) findViewById(R.id.weight);

        repsBtn.setOnClickListener(this);
        setsBtn.setOnClickListener(this);
        weightBtn.setOnClickListener(this);

        GraphView graph = (GraphView) findViewById(R.id.graph);
        LineGraphSeries<DataPoint> set = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(1, 3),
                new DataPoint(2, 5),
                new DataPoint(3, 4),
                new DataPoint(4, 3),
                new DataPoint(5, 6),
                new DataPoint(6, 4),
                new DataPoint(7, 3),
                new DataPoint(8, 5),
                new DataPoint(9, 2),
                new DataPoint(10, 4),
                new DataPoint(11, 1),
                new DataPoint(12, 3),
                new DataPoint(13, 5),
                new DataPoint(14, 2),
                new DataPoint(15, 3),
                new DataPoint(16, 2),
                new DataPoint(17, 5),
                new DataPoint(18, 4),
                new DataPoint(19, 3),
                new DataPoint(20, 5)/*,
                new DataPoint(21, 6),
                new DataPoint(22, 1),
                new DataPoint(23, 4),
                new DataPoint(24, 3),
                new DataPoint(25, 5),
                new DataPoint(26, 6),
                new DataPoint(27, 4),
                new DataPoint(28, 6),
                new DataPoint(29, 1),
                new DataPoint(30, 4),
                new DataPoint(31, 3)*/
        });
        graph.addSeries(set);
        set.setColor(Color.BLUE);

        graph.getViewport().setMinX(1);
        graph.getViewport().setMaxX(20);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.reps:
                Intent resumeRep = new Intent(SetGraph.this, RepGraph.class);
                startActivity(resumeRep);
                break;
            case R.id.sets:
                Intent resume = new Intent(SetGraph.this, Graph.class);
                startActivity(resume);
                break;
            case R.id.weight:
                Intent resumeWeight = new Intent(SetGraph.this, WeightGraph.class);
                startActivity(resumeWeight);
                break;
        }
    }

}
